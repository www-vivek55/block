<?php
declare(strict_types=1);

namespace W3\BlockTags\Ui\DataProvider\Tag\Form;

use W3\BlockTags\Model\ResourceModel\TagData\CollectionFactory;
use Magento\Cms\Api\BlockRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\Request\Http;
use Magento\Ui\DataProvider\AbstractDataProvider;

class TagFormDataProvider extends AbstractDataProvider
{
    /**
     * @var \W3\BlockTags\Model\ResourceModel\Tag\Collection
     */
    protected $collection;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;

    /**
     * @var \Magento\Cms\Api\BlockRepositoryInterface
     */
    protected $_blockRepository;

    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $_searchCriteriaBuilder;

    /**
     * TagFormDataProvider constructor.
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $tagCollectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param Http $request
     * @param BlockRepositoryInterface $blockRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $tagCollectionFactory,
        DataPersistorInterface $dataPersistor,
        Http $request,
        BlockRepositoryInterface $blockRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $tagCollectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->request = $request;
        $this->_blockRepository = $blockRepository;
        $this->_searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->meta = $this->prepareMeta($this->meta);
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * Prepares Meta
     *
     * @param array $meta
     * @return array
     */
    public function prepareMeta(array $meta)
    {
        return $meta;
    }

    /**
     * Get Data
     *
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }

        $searchCriteria = $this->_searchCriteriaBuilder->create();
        $cmsBlocks = $this->_blockRepository->getList($searchCriteria)->getItems();
        $block_id = $this->request->getParam('block_id');
        $this->collection->getSelect()->reset(\Magento\Framework\DB\Select::WHERE);
        $blockData = $this->collection->addFieldToFilter('block_id', $block_id);

        $item = [];
        foreach ($blockData->getItems() as $itemB) {
            $item['tags'][] = $itemB->getData('tag_id');
        }

        /** @var $tag \W3\BlockTags\Model\Tag */
        $this->loadedData = [];
        foreach ($cmsBlocks as $tag) {
            if ($tag->getData('block_id')==$block_id) {
                $this->loadedData[$tag->getId()] = $tag->getData();
            }
        }
        $data = $this->dataPersistor->get('current_model');
        if (!empty($data)) {
            $tag = $this->collection->getNewEmptyItem();
            $tag->setData($data);
            $this->loadedData[$tag->getId()] = $tag->getData();
            $this->dataPersistor->clear('current_model');
        }

        $firstKey = 0;
        $blockData = [];
        foreach ($this->loadedData as $key => $loadData) {
            $firstKey = $key;
            $blockData = $loadData;
        }
        return [$firstKey=>array_merge($blockData, $item)];
    }
}
