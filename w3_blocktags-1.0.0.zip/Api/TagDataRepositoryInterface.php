<?php
declare(strict_types=1);

namespace W3\BlockTags\Api;

use W3\BlockTags\Api\Data\TagDataInterface;

interface TagDataRepositoryInterface
{
    /**
     * Get TagIdBYId
     *
     * @param int $id
     * @return TagDataInterface
     */
    public function getTagIdById(int $id): TagDataInterface;

    /**
     * Get TagData
     *
     * @return TagDataInterface
     */
    public function getTagData(): TagDataInterface;

    /**
     * Save TagData
     *
     * @param Data\TagDataInterface $tagData
     * @return TagDataInterface
     */
    public function saveTagData(TagDataInterface $tagData): TagDataInterface;

    /**
     * Delete TagDataById
     *
     * @param int $id
     * @return void
     */
    public function deleteTagDataById(int $id);
}
