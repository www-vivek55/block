<?php
declare(strict_types=1);

namespace W3\BlockTags\Api\Data;

interface TagInterface
{
    /*
     * Constant
     */
    public const ID = 'tag_id';
    public const TAG = 'tag';

    /**
     * Get Id
     *
     * @return int
     */
    public function getId();

    /**
     * Get Tag
     *
     * @return string
     */
    public function getTag(): string;

    /**
     * Set ID
     *
     * @param int $tid
     * @return TagInterface
     */
    public function setId(int $tid): TagInterface;

    /**
     * Set Tag
     *
     * @param string $tag
     * @return TagInterface
     */
    public function setTag(string $tag): TagInterface;
}
