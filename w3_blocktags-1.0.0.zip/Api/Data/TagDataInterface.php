<?php
declare(strict_types=1);

namespace W3\BlockTags\Api\Data;

interface TagDataInterface
{
    /**
     * Constants
     */
    public const ID = 'entity_id';
    public const BID = 'block_id';
    public const TID = 'tag_id';

    /**
     * Get Entity ID
     *
     * @return int
     */
    public function getId();

    /**
     * Get Block ID
     *
     * @return int
     */
    public function getBlockId();

    /**
     * Get Tag ID
     *
     * @return int
     */
    public function getTagId();

    /**
     * Set Entity ID
     *
     * @param int $id
     * @return TagDataInterface
     */
    public function setId($id);

    /**
     * Set Block Id
     *
     * @param int $blockId
     * @return TagDataInterface
     */
    public function setBlockId($blockId);

    /**
     * Set Tag Id
     *
     * @param int $tid
     * @return TagDataInterface
     */
    public function setTagId($tid);
}
