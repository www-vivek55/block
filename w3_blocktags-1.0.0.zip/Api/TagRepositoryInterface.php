<?php
declare(strict_types=1);

namespace W3\BlockTags\Api;

use W3\BlockTags\Api\Data\TagInterface;

interface TagRepositoryInterface
{
    /**
     * Get Tag By Id
     *
     * @param int $tid
     * @return TagInterface
     */
    public function getTagById(int $tid): TagInterface;

    /**
     * Save Tag
     *
     * @param Data\TagInterface $tag
     * @return TagInterface
     */
    public function saveTag(TagInterface $tag): TagInterface;

    /**
     * Delete TagById
     *
     * @param int $tid
     * @return mixed
     */
    public function deleteTagById(int $tid): mixed;
}
