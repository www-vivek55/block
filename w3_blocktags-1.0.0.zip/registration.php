<?php
/**
 * Copyright © BlockTags module All rights reserved.
 * See COPYING.txt for license details.
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'W3_BlockTags', __DIR__);
