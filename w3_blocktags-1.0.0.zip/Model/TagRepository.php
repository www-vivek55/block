<?php
declare(strict_types=1);

namespace W3\BlockTags\Model;

use W3\BlockTags\Api\Data\TagInterface;
use W3\BlockTags\Api\TagRepositoryInterface;
use W3\BlockTags\Model\ResourceModel\Tag;
use Magento\Framework\Exception\AlreadyExistsException;

class TagRepository implements TagRepositoryInterface
{

    /**
     * @var Tag
     */
    private Tag $tag;

    /**
     * @var TagFactory
     */
    private TagFactory $tagFactory;

    /**
     * TagRepository constructor.
     * @param Tag $tag
     * @param TagFactory $tagFactory
     */
    public function __construct(
        Tag $tag,
        TagFactory $tagFactory
    ) {
        $this->tag = $tag;
        $this->tagFactory = $tagFactory;
    }

    /**
     * Get TagById
     *
     * @param int $tid
     * @inheirtDoc
     */
    public function getTagById(int $tid): TagInterface
    {
        $tag = $this->tagFactory->create()->load($tid);
        return $tag;
    }

    /**
     * Save Tag
     *
     * @param TagInterface $tag
     * @inheirtDoc
     */
    public function saveTag(TagInterface $tag): TagInterface
    {
        if ($tag->getId() == null) {
            $this->tag->save($tag);
            return $tag;
        } else {
            $newTag = $this->tagFactory->create()->load($tag->getId());
            foreach ($tag->getData() as $key => $value) {
                $newTag->setData($key, $value);
            }
            $this->tag->save($newTag);
            return $newTag;
        }
    }

    /**
     * Delete TagById
     *
     * @param int $id
     * @inheirtDoc
     */
    public function deleteTagById(int $id): mixed
    {
        $tag = $this->tagFactory->create()->load($id);
        $tag->delete();
    }
}
