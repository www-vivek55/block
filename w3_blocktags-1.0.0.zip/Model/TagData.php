<?php
declare(strict_types=1);

namespace W3\BlockTags\Model;

use W3\BlockTags\Api\Data\TagDataInterface;
use W3\BlockTags\Model\ResourceModel\TagData as TagDataResource;
use Magento\Framework\Model\AbstractModel;

class TagData extends AbstractModel implements TagDataInterface
{
    /**
     * Init TagDataResource
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(TagDataResource::class);
    }

    /**
     * Int
     *
     * @return int
     */
    public function getId()
    {
        return $this->getData(TagDataInterface::ID);
    }

    /**
     * Int
     *
     * @return int
     */
    public function getBlockId()
    {
        return $this->getData(TagDataInterface::BID);
    }

    /**
     * Int
     *
     * @return int
     */
    public function getTagId()
    {
        return $this->getData(TagDataInterface::TID);
    }

    /**
     * TagDataInterface
     *
     * @param int $id
     * @return TagDataInterface
     */
    public function setId($id)
    {
        return $this->setData(TagDataInterface::ID, $id);
    }

    /**
     * TagDataInterface
     *
     * @param int $blockId
     * @return TagDataInterface
     */
    public function setBlockId($blockId)
    {
        return $this->setData(TagDataInterface::BID, $blockId);
    }

    /**
     * TagDataInterface
     *
     * @param int $tid
     * @return TagDataInterface
     */
    public function setTagId($tid)
    {
        return $this->setData(TagDataInterface::TID, $tid);
    }
}
