<?php
declare(strict_types=1);

namespace W3\BlockTags\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\Model\AbstractModel;
use Magento\Cms\Model\BlockFactory;

class TagData extends AbstractDb
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('W3_tag_data', 'entity_id');
    }
}
