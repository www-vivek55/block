<?php
declare(strict_types=1);

namespace W3\BlockTags\Model;

use W3\BlockTags\Api\Data\TagInterface;
use W3\BlockTags\Model\ResourceModel\Tag as TagResource;
use Magento\Framework\Model\AbstractModel;

class Tag extends AbstractModel implements TagInterface
{
    /**
     * Init TagResource
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(TagResource::class);
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->getData(TagInterface::ID);
    }

    /**
     * Get Tag
     *
     * @inheirtDoc
     */
    public function getTag(): string
    {
        return $this->getData(TagInterface::TAG);
    }

    /**
     * Set Id
     *
     * @param int|mixed $tid
     * @return TagInterface|Tag
     */
    public function setId($tid): Tag
    {
        return $this->setData(TagInterface::ID, $tid);
    }

    /**
     * TagInterface
     *
     * @param string $tag
     * @inheirtDoc
     */
    public function setTag(string $tag):TagInterface
    {
        return $this->setData(TagInterface::TAG, $tag);
    }
}
