<?php
declare(strict_types=1);

namespace W3\BlockTags\Model\Config\Source;

use W3\BlockTags\Model\ResourceModel\Tag\CollectionFactory;
use Magento\Framework\Data\OptionSourceInterface;

class Tag implements OptionSourceInterface
{

    /**
     * @var array
     */
    protected array $options;

    /**
     * @var CollectionFactory
     */
    protected CollectionFactory $collectionFactory;

    /**
     * Tag constructor.
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(CollectionFactory $collectionFactory)
    {
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray(): array
    {
        $this->options = [];
        if (empty($this->options)) {
            $collection = $this->collectionFactory->create();
            foreach ($collection as $item) {
                $this->options[] = [
                    'label' => $item->getData('tag'),
                    'value' => $item->getData('tag_id'),
                ];
            }
        }
        return $this->options;
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray(): array
    {
        $array = [];
        foreach ($this->toOptionArray() as $item) {
            $array[$item['value']] = $item['label'];
        }
        return $array;
    }
}
