<?php
declare(strict_types=1);

namespace W3\BlockTags\Model;

use W3\BlockTags\Api\Data;
use W3\BlockTags\Api\Data\TagDataInterface;
use W3\BlockTags\Api\TagDataRepositoryInterface;
use W3\BlockTags\Model\ResourceModel\TagData;
use W3\BlockTags\Model\ResourceModel\TagData\CollectionFactory;
use Magento\Framework\Exception\AlreadyExistsException;

class TagDataRepository implements TagDataRepositoryInterface
{
    /**
     * @var tagData
     */
    private TagData $tagData;

    /**
     * @var TagDataFactory
     */
    private TagDataFactory $tagDataFactory;

    /**
     * @var CollectionFactory
     */
    private CollectionFactory $collectionFactory;

    /**
     * TagDataRepository constructor.
     * @param CollectionFactory $collectionFactory
     * @param TagData $tagData
     * @param TagDataFactory $tagDataFactory
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        TagData $tagData,
        TagDataFactory $tagDataFactory
    ) {
        $this->tagData = $tagData;
        $this->tagDataFactory = $tagDataFactory;
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * Get TagIdById
     *
     * @param int $id
     * @return TagDataInterface
     */
    public function getTagIdById(int $id): TagDataInterface
    {
        $tag = $this->tagDataFactory->create()->load($id);
        return $tag;
    }

    /**
     * Get TagData
     *
     * @return TagDataInterface|TagData\Collection
     */
    public function getTagData(): TagDataInterface
    {
        return $this->collectionFactory->create();
    }

    /**
     * Save TagData
     *
     * @param TagDataInterface $tagData
     * @return TagDataInterface
     * @throws AlreadyExistsException
     */
    public function saveTagData(TagDataInterface $tagData): TagDataInterface
    {
        if ($tagData->getTagId() == null) {
            $this->tagData->save($tagData);
            return $tagData;
        } else {
            $newTag = $this->tagDataFactory->create()->load($tagData->getTagId());
            foreach ($tagData->getData() as $key => $value) {
                $newTag->setData($key, $value);
            }
            $this->tagData->save($newTag);
            return $newTag;
        }
    }

    /**
     * Delete TagDataById
     *
     * @param int $id
     * @throws \Exception
     */
    public function deleteTagDataById(int $id)
    {
        $tag = $this->tagDataFactory->create()->load($id);
        $tag->delete();
    }
}
