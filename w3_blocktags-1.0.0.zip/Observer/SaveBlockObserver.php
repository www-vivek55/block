<?php
declare(strict_types=1);

namespace W3\BlockTags\Observer;

use W3\BlockTags\Model\TagDataFactory;
use Magento\Cms\Api\BlockRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\ObserverInterface;

class SaveBlockObserver implements ObserverInterface
{
    /**
     * @var RequestInterface
     */
    protected $_request;

    /**
     * @var TagDataFactory
     */
    protected $model;

    /**
     * SaveBlockObserver constructor.
     * @param RequestInterface $request
     * @param TagDataFactory $tagDataFactory
     * @param BlockRepositoryInterface $blockRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        RequestInterface $request,
        TagDataFactory $tagDataFactory,
        BlockRepositoryInterface $blockRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->_request = $request;
        $this->model = $tagDataFactory;
        $this->_blockRepository = $blockRepository;
        $this->_searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * Save
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {

        $searchCriteria = $this->_searchCriteriaBuilder->create();
        $cmsBlocks = $this->_blockRepository->getList($searchCriteria)->getItems();
        foreach ($cmsBlocks as $tag) {
            $block_id = $tag->getId();
        }
        $blockId = $this->_request->getParam('block_id');
        $tags = $this->_request->getParam('tags');
        $this->tagDelete($blockId);
        foreach ($tags as $tag) {
            $tagData = $this->model->create();
            $blockData = $tagData->getCollection()
                ->addFieldToFilter('block_id', $blockId)
                ->addFieldToFilter('tag_id', $tag);
            if (!count($blockData)) {
                if (empty($blockId)) {
                    $tagData->setBlockId($block_id);
                    $tagData->setTagId($tag);
                    $tagData->save();
                } else {
                    $tagData->setBlockId($blockId);
                    $tagData->setTagId($tag);
                    $tagData->save();
                }
            }
        }
    }

    /**
     * Delete tag
     *
     * @param int $id
     */
    public function tagDelete($id)
    {
        $modelTag = $this->model->create();
        $modelTag->getCollection()
            ->addFilter('block_id', $id)
            ->walk('delete');
    }
}
