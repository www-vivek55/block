<?php
declare(strict_types=1);

namespace W3\BlockTags\Controller\Adminhtml\Tag;

use W3\BlockTags\Model\Tag;
use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Cms\Block\Block;
use Magento\Framework\App\Request\Http;
use Magento\Framework\View\Layout;
use Magento\Framework\View\Result\PageFactory;

class Save extends Action
{
    /**
     * @var PageFactory
     */
    private $pageFactory;
    /**
     * @var Tag
     */
    protected $model;

    /**
     * @var Block
     */
    protected $subject;
    /**
     * @var RedirectFactory
     */
    protected $resultRedirectFactory;

    /**
     * Save constructor.
     * @param RedirectFactory $redirectFactory
     * @param PageFactory $pageFactory
     * @param Tag $tag
     * @param Http $request
     * @param Block $subject
     * @param Layout $layout
     * @param Action\Context $context
     */
    public function __construct(
        RedirectFactory $redirectFactory,
        PageFactory $pageFactory,
        Tag $tag,
        Http $request,
        Block $subject,
        Layout $layout,
        Action\Context $context
    ) {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
        $this->model = $tag;
        $this->request = $request;
        $this->subject = $subject;
        $this->layout = $layout;
        $this->resultRedirectFactory = $redirectFactory;
    }

    /**
     * Save
     *
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     * @throws \Exception
     */
    public function execute()
    {
        try {
            $title = $this->getRequest()->getPostValue('title');
            if (is_array($title)) {
                $title = implode(" ", $title);
            }
            $tag = $this->model->setTag($title);
            $collectionData = $this->model->getCollection()->addFieldToFilter('tag', $title);
            if (!count($collectionData)) {
                $tag->save();
                $this->messageManager->addSuccessMessage(__('Tag Saved Successfully.'));
            } else {
                $this->messageManager->addError(__('Already Exist.'));
            }
        } catch (Exception $e) {
            $this->messageManager->addError(nl2br($e->getMessage()));
        }

        $hasError = (bool)$this->messageManager->getMessages()->getCountByType(
            \Magento\Framework\Message\MessageInterface::TYPE_ERROR
        );
        $block = $this->layout->getMessagesBlock();
        $this->getResponse()->setBody(json_encode(
            [
                'messages' => $block->getGroupedHtml(),
                'error' => $hasError,
                'model' => $tag->toArray(),
            ]
        ));
    }
}
